<div id="footer">
  <p>Universitas Kristen Dutawacana - Copyright 2018 - All Right Reserved</p>
</div>
